To use:

1) Put all of the Neuroshare '.m' scripts into a directory
2) Put the mexprog.dll into the same directory
3) Put the NeuroshareDLL into the same directory (optional)
4) Change your matlab path to this directory  
       -or-
   Add this directory to your Matlab path
5) Done.
